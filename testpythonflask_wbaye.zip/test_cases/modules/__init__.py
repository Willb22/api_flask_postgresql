from .functions import try_delete
from .functions import try_post
from .functions import try_get
from .functions import try_put
